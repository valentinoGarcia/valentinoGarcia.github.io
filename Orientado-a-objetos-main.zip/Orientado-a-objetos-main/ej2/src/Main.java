
import java.util.ArrayList;
import java.util.Scanner;
public class Main {




    public static void main(String[] args) {

        ArrayList<Persona> lista = new ArrayList<>();
        Persona p1 =new Persona();
        RegistroDePersona menu = new RegistroDePersona();
        menu.menu(lista);

  }
}
